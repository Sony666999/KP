// Selecting form and input elements
const form = document.querySelector("form");
const passwordInput = document.getElementById("password");
const passToggleBtn = document.getElementById("pass-toggle-btn");

// Function to display error messages
const showError = (field, errorText) => {
    field.classList.add("error"); // Добавляем класс error для выделения
    const errorElement = document.createElement("small");
    errorElement.classList.add("error-text"); // Создаем элемент для текста ошибки
    errorElement.innerText = errorText; // Устанавливаем текст ошибки
    field.closest(".form-group").appendChild(errorElement); // Добавляем текст ошибки в группу формы
}

// Function to handle form submission
const handleFormData = (e) => {
    e.preventDefault(); // Отменяем стандартное поведение отправки формы

    // Retrieving input elements
    const fullnameInput = document.getElementById("fullname");
    const emailInput = document.getElementById("email");
    const dateInput = document.getElementById("date");
    const genderInput = document.getElementById("gender");

    // Getting trimmed values from input fields
    const fullname = fullnameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    const date = dateInput.value;
    const gender = genderInput.value;

    // Regular expression pattern for email validation
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    // Clearing previous error messages
    document.querySelectorAll(".form-group .error").forEach(field => field.classList.remove("error"));
    document.querySelectorAll(".error-text").forEach(errorText => errorText.remove());

    // Performing validation checks
    let hasError = false; // Флаг для отслеживания наличия ошибок
    if (fullname === "") {
        showError(fullnameInput, "Введите ваше имя");
        hasError = true; // Устанавливаем флаг, если есть ошибка
    }
    if (!emailPattern.test(email)) {
        showError(emailInput, "Введите корректный адрес электронной почты");
        hasError = true; // Устанавливаем флаг, если есть ошибка
    }
    if (password === "") {
        showError(passwordInput, "Введите ваш пароль");
        hasError = true; // Устанавливаем флаг, если есть ошибка
    }
    if (date === "") {
        showError(dateInput, "Выберите вашу дату регистрации");
        hasError = true; // Устанавливаем флаг, если есть ошибка
    }
    if (gender === "") {
        showError(genderInput, "Выберите ваш пол");
        hasError = true; // Устанавливаем флаг, если есть ошибка
    }

    // Checking for any remaining errors before form submission
    if (hasError) return; // Если есть ошибки, не отправляем форму

    // Submitting the form
    form.submit();
}

// Toggling password visibility
passToggleBtn.addEventListener('click', () => {
    passToggleBtn.className = passwordInput.type === "password" ? "fa-solid fa-eye-slash" : "fa-solid fa-eye";
    passwordInput.type = passwordInput.type === "password" ? "text" : "password";
});

// Handling form submission event
form.addEventListener("submit", handleFormData);